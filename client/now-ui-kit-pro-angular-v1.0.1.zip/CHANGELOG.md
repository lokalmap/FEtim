# Change Log

## [1.0.1] 2018-03-01
### Fixes
- optimised size of images
- fixed links in static documentation

## [1.0.0] 2018-02-15
### Original Release
